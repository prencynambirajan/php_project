<?php
require "includes/common.php";
?>
<html>
    <head>
        <title>About Us | E-Store.com</title>
        <link rel="shortcut icon" href="img\srtcticon.png" type="image/png">
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
    </head>
    
      
<body>
    <?php include 'includes/header.php'; ?>
    <br>
        <div class="container">
            <div class="col-sm-4">
                <div class="panel panel-default">
                   <div class="panel-body">
                    <h3 style="color:orange" class="color">WHO WE ARE</h3>
                    <img src="./img/bg1.jpg" alt="about image"><br><br>
                    <p>Fashionista started its journey in April 2008. The only Company to revolutionize "B" Cities in terms of their needs of latest Fashion & Lifestyle products.

Fashionista has now entered its 10th year with 210+ exhibitions. The only Company to target 26 cities across India and yet not stopping. First mover advantage has helped Fashionista in developing itself from just a name to a 'Successful Brand' in India which sets a 'Benchmark' for others to follow.

Fashionista has always been associated with Media and Celebrities, which adds all the glitter & glamour to the Exhibitions. Fashionista has the best Designers and Exhibitors from all across India and abroad.


                </div>
                </div>
            </div>
            
            
            <div class="col-sm-4">
                <div class="panel panel-default">
                   <div class="panel-body">
                    <h3 style="color:orange" class="color">OUR PARTNERS</h3><br><br>
                    <h4 style="color:blue">Lakme</h4>
                    <p>Lakmé is an Indian cosmetics brand which is owned by Hindustan Unilever. Having Kareena Kapoor and Ananya Pandey as the ambassador, it ranked at number 1 among the cosmetics brands in India. [2] [3][4] Lakme started as a 100% subsidiary of Tata Oil Mills (Tomco). It was named after the French opera Lakmé, which itself is the French form of Lakshmi (the goddess of wealth) who is renowned for her beauty. It was started in 1952 famously, because then Prime Minister Jawaharlal Nehru was concerned that Indian women were spending precious foreign exchange on beauty products and personally requested JRD Tata to manufacture them in India.[5] Simone Tata joined the company as director and went on to become the chairperson.[6] In 1996, Tata sold off their stakes in Lakmé Lever to HUL, for Rs 200 Crore[7](45 million US$).

</p>
                    <br>
                    <h4 style="color:blue">Maybelline</h4>
                    <p>The Maybelline Company was created by a 19-year-old entrepreneur named Thomas Lyle Williams in 1915. Williams noticed his older sister Mabel applying a mixture of Vaseline and coal dust to her eyelashes to give them a darker, fuller look. He adapted it with a chemistry set and produced a product sold locally called Lash-Brow-Ine. Williams renamed his eye beautifier Maybelline in honor of the sister who gave him the idea. In 1917 the company produced Maybelline Cake Mascara, "the first modern eye cosmetic for everyday use" and Ultra Lash in the 1960s, which was the first mass-market automatic.</p>
                    <br>
                    <h4 style="color:blue">Huda Beauty</h4>
                    <p>Huda Beauty is a cosmetics line launched in 2013 by Huda Kattan.[1][2][3][4] The founder, Kattan, was chosen as one of "The 25 Most Influential People on the Internet" by Time in 2017,[3] listed as one of The Richest Self-Made Women and one of the Top Three Beauty Influencers by Forbes.[5][6] In the span of 5 years, the brand has built a positive reputation on some of its products, such as fake eyelashes series, a collection of foundation, and some face palettes.</p>
                    </div>
                </div>
                </div>
            
            
            <div class="col-sm-4">
                <div class="panel panel-default">
                   <div class="panel-body">
                    <h3 style="color:orange" class="color">SHIPPING</h3><br><br>
                                <p>Shipping Speed	Charges for Prime Members	Charges for Non-Prime Members
One-Day Delivery*	Free	Rs. 100
Two-Day Delivery*	Free	Rs. 80
No-Rush Delivery*	Free and avail Rs.15 cashback. For more details, go to About the No-Rush Shipping Program.	NA
Standard Delivery* (2-4/4-7/7-10 business days)	Free	A minimum total order amount of Rs. 499 for items Fulfilled by Fashionista is required for an order to qualify for free delivery. A delivery charge of Rs. 40 will be charged for orders below Rs. 499.
Same-Day Delivery*	Discounted price of Rs. 50	Rs. 150
Morning Delivery*	Discounted price of Rs. 50.	Rs. 150
Scheduled Delivery	FREE	FREE (For some FBA items, Rs. 50 will be charged for weekend and next-day delivery slot.)
Express Delivery for Prime Now	Discounted price of Rs. 49.	NA
Fashionista Pantry
Next-day Delivery/Scheduled Delivery	Discounted Price of Rs. 30	</p>
                              
                        </div>
                </div>
            </div>
            
        </div>
        <?php include 'includes/footer.php'; ?>
    </body>
</html>
